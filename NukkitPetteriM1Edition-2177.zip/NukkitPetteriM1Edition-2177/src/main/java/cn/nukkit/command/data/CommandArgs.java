package cn.nukkit.command.data;

import com.google.gson.JsonElement;

import java.util.HashMap;

public class CommandArgs extends HashMap<String, JsonElement> {
}
