package cn.nukkit.command.data;

import java.util.ArrayList;
import java.util.List;

public class CommandDataVersions {

    public List<CommandData> versions = new ArrayList<>();
}
