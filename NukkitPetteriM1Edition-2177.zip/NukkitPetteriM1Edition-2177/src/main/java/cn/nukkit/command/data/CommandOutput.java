package cn.nukkit.command.data;

public class CommandOutput {

    public String[] format_strings = new String[0];
}
