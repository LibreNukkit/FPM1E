package cn.nukkit.command.data;

public class CommandOverload {

    public CommandInput input = new CommandInput();
    public CommandOutput output = new CommandOutput();
}
