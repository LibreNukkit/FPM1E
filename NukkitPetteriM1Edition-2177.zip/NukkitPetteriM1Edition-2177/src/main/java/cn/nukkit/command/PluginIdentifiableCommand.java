package cn.nukkit.command;

import cn.nukkit.plugin.Plugin;

/**
 * @author MagicDroidX
 * Nukkit Project
 */
public interface PluginIdentifiableCommand {

    Plugin getPlugin();
}
