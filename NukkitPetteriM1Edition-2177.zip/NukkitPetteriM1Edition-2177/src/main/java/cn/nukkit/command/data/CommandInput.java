package cn.nukkit.command.data;

public class CommandInput {

    public CommandParameter[] parameters = new CommandParameter[0];
}
