package cn.nukkit.entity;

public interface EntityBoss {
}
