package cn.nukkit.entity;

/**
 * @author MagicDroidX
 * Nukkit Project
 */
public interface EntitySmite {
}
