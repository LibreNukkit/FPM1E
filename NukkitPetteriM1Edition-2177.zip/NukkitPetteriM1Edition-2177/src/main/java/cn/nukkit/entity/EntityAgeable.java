package cn.nukkit.entity;

/**
 * @author MagicDroidX
 * Nukkit Project
 */
public interface EntityAgeable {

    boolean isBaby();

    void setBaby(boolean baby);
}
