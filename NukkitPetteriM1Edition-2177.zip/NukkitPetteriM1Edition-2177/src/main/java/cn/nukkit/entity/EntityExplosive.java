package cn.nukkit.entity;

/**
 * @author Nukkit Project Team
 */
public interface EntityExplosive {

    void explode();
}
