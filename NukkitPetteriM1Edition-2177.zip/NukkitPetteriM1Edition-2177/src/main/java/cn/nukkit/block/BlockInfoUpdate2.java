package cn.nukkit.block;

/**
 * Created by PetteriM1
 */
public class BlockInfoUpdate2 extends BlockSolid {

    @Override
    public int getId() {
        return INFO_UPDATE2;
    }

    @Override
    public String getName() {
        return "Update Game Block";
    }
}
