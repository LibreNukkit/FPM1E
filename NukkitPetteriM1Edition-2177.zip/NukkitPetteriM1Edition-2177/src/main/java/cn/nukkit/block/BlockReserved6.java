package cn.nukkit.block;

/**
 * Created by PetteriM1
 */
public class BlockReserved6 extends BlockSolid {

    @Override
    public int getId() {
        return RESERVED6;
    }

    @Override
    public String getName() {
        return "reserved6";
    }
}
