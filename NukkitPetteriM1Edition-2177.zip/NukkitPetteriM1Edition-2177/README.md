# Nukkit PetteriM1 Edition
This is a special version of [Nukkit](https://github.com/CloudburstMC/Nukkit) Minecraft Bedrock Edition server software made for my server [SuomiCraft PE](https://suomicraft-pe.tk/).

See the [wiki](https://github.com/PetteriM1/NukkitPetteriM1Edition/wiki) for more details.

<!--[![CircleCI branch](https://img.shields.io/circleci/project/github/PetteriM1/NukkitPetteriM1Edition/master.svg)](https://circleci.com/gh/PetteriM1/NukkitPetteriM1Edition/tree/master)-->
>[Download](https://github.com/PetteriM1/NukkitPetteriM1Edition/releases)
